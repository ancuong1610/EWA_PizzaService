"use strict";
let request = new XMLHttpRequest();

function processData() {
  "use strict";
  if (request.readyState === 4) {
    // Uebertragung = DONE
    if (request.status === 200) {
      // HTTP-Status = OK
      if (request.responseText != null) {
        processResponse(request.responseText); // Daten verarbeiten
      } else console.error("Dokument ist leer");
    } else console.error("Uebertragung fehlgeschlagen");
  } // else; // Uebertragung laeuft noch
}

function sendRequest(RequestMethod, RequestUri, RequestPostData) {
    "use strict";
    if ((RequestMethod!=="") && (RequestUri!=="")) {

        console.log("Sending a " + RequestMethod + "-Request opening the URI: " + RequestUri + " with Post-data: " + RequestPostData);

        request.open(RequestMethod, RequestUri);
        request.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); 
        request.onreadystatechange = processData;
        request.send(RequestPostData);
    }
}

// ********************** Ende der Zulieferung ********************************/

function sendData() {

}


function processResponse(jsonData) {

}
